Clear-Host
Write-Host "=== MRPS ===" -ForegroundColor Cyan
Write-Host "1.Chipper Doodle"
Write-Host "2.Deliberate Thought"
Write-Host "3.Electrodoodle"
Write-Host "4.How it Begins"
Write-Host "5.Itty Bitty 8 Bit"
Write-Host "6.Klockworx"
Write-Host "7.New Friendly"
Write-Host "8.One Sly Move"
Write-Host "9.Pamgaea"
Write-Host "10.PinBall Spring"
Write-Host "11.Presenterator"
Write-Host "12.Rollin at 5"
Write-Host "13.Show your Moves"
Write-Host "14.Super Friendly"
Write-Host "15.Theme For Harold 3"
Write-Host "16.Theme for Harold 2"
Write-Host "17.Theme for Harold 1"
Write-Host "18.Wallpaper"
Write-Host "19.Cipher"

$opcion = Read-Host "Selected a option"

# BUSCADOR PORTÁTIL: Busca la carpeta de música justo al lado del .exe descomprimido
$RutaBase = "$PSScriptRoot\ALBUM Light ElectronicKEVIN"

switch ($opcion) {
    "1"  { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Chipper Doodle.mp3" }
    "2"  { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Deliberate Thought.mp3" }
    "3"  { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Electrodoodle.mp3" }
    "4"  { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\How it Begins.mp3" }
    "5"  { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Itty Bitty 8 Bit.mp3" }
    "6"  { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Klockworx.mp3" }
    "7"  { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\New Friendly.mp3" }
    "8"  { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\One Sly Move.mp3" }
    "9"  { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Pamgaea.mp3" }
    "10" { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Pinball Spring.mp3" }
    "11" { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Presenterator.mp3" }
    "12" { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Rollin at 5 - electronic.mp3" }
    "13" { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Show Your Moves.mp3" }
    "14" { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Super Friendly.mp3" }
    "15" { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Theme for Harold var 3.mp3" }
    "16" { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Theme for Harold var 2.mp3" }
    "17" { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Theme for Harold var 1.mp3" }
    "18" { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Wallpaper.mp3" }
    "19" { Write-Host "Music Open!" -ForegroundColor Yellow; Start-Process "$RutaBase\Cipher.mp3" }
    Default { Write-Host "Option INCORRECT." -ForegroundColor Red }
}

Write-Host "Press Enter"